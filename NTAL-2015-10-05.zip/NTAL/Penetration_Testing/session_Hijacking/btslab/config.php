<?php

$db_name="btslab";
$db_user="root";
$db_password="";
$db_server="localhost";

?>
