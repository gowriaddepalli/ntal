			
		</div>
	
		<div class="clear"></div>
	</div>
		
	<center>	<p>Copyrights &copy; <b><a href="http://www.cysecurity.org">Cyber Security & Privacy Foundation </a> </p></b></center>
		
	

</div>
</body>
</html>
