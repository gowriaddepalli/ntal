<?php
header("Location: admincontrol.php");
?>
